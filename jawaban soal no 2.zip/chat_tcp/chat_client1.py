import socket
import threading

HOST = "127.0.0.1"
PORT = 5050

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((HOST, PORT))

def listen_server():
    while True:
        try:
            msg = client.recv(1024).decode()
            print("\n[Pesan baru] " + msg)
        except:
            print("Koneksi terputus.")
            client.close()
            break

thread = threading.Thread(target=listen_server)
thread.daemon = True
thread.start()

print("Tersambung ke chat server.")
print("Ketik pesan lalu Enter:")

while True:
    msg = input("")
    client.send(msg.encode())
