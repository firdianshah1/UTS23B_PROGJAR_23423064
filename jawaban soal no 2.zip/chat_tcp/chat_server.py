import socket
import threading

HOST = "0.0.0.0"
PORT = 5050

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((HOST, PORT))
server.listen()

clients = []

print("[SERVER] Chat server berjalan di port", PORT)

def broadcast(message, sender_conn):
    for conn, addr in clients:
        if conn != sender_conn:
            try:
                conn.send(message)
            except:
                conn.close()
                clients.remove((conn, addr))

def handle_client(conn, addr):
    print(f"[SERVER] Client terhubung: {addr}")
    clients.append((conn, addr))

    while True:
        try:
            msg = conn.recv(1024)
            if not msg:
                break
            print(f"[{addr}] {msg.decode()}")
            broadcast(msg, conn)
        except:
            break

    print(f"[SERVER] Client terputus: {addr}")
    conn.close()
    clients.remove((conn, addr))

def start():
    print("[SERVER] Menunggu client...")
    while True:
        conn, addr = server.accept()
        thread = threading.Thread(target=handle_client, args=(conn, addr))
        thread.start()

start()
